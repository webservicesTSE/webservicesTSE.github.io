package customconverter;

public class Custom {
}
