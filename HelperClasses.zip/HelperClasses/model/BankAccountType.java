package model;

public class BankAccountType {

}
