package enterprise.service;

import java.math.BigDecimal;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import model.BankCustomer;
import enterprise.hello_stateless_ejb.StatelessLocal;


@Stateless    
@WebService
public class BankService {
	@EJB(beanName="BK")  
    private StatelessLocal metier;
   
    
    @WebMethod
    public String getUserInfo(@WebParam(name="username") String user){
    
    	
		return metier.getUser(user).getUsername();
    }
    
    @WebMethod
    public String transferMoney(@WebParam(name="username") String user, @WebParam(name="transferAmount ") BigDecimal transferAmount, @WebParam(name="fromAccount") String fromAccount,  @WebParam(name="toAccount") String toAccount) throws Exception{
    
    	
    	
    	BankCustomer customer = metier.getUser(user);
    	
    	metier.transferFunds( customer, fromAccount, toAccount, transferAmount );
    	
    	
		return "Transfer Successful";
    }
}
