package enterprise.hello_stateless_ejb;

import java.math.BigDecimal;

import javax.ejb.Local;

import model.BankCustomer;
@Local
public interface StatelessLocal {
	  public String hello();
	    
	   

	    public BankCustomer getUser(String user);
	    public void transferFunds( BankCustomer bankCustomerEntity, String fromAccountNo, String toAccountNo, BigDecimal amount ) throws Exception;

}
